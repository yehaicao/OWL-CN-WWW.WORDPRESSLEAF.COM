<?php
/**
 *  WordPress Google Places Widget Frontend
 *
 * @description:  This file is used to markup the public-facing widget.
 *
 * @since      : 1.0.0
 *
 * @created    : 3/4/14
 */
?>

<div class="hello">Hello</div>