=== Plugin Name ===

Plugin Name: Tiled Galleries
Plugin URL: 
Description: 
Version: 1.0
Author: Web Invader
Author URI: 
License: GPLv2 or later
License URI: 

== Changelog ==

= 0.1 =
*Initial Release
