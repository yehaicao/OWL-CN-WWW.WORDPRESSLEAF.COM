=== Instagram Slider Widget ===
Contributors: jetonr
Tags: instagram, slider, widget, images
Donate link: http://goo.gl/RZiu34
Requires at least: 3.5
Tested up to: 4.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Based on http://jrwebstudio.com/instagram-slider/ ( jetonr )

Instagram Slider Widget is a responsive slider widget that shows 24 latest images from a public instagram user.

== Description ==
* Instagram Slider Widget is a responsive slider widget that shows 24 latest images from a public instagram user. 
= Features =
* Images from instagram are imported as wordpress attachments
* Display Images in Slider or Thumbnails
* No Api Key Needed
* Link images to user profile, image url, locally saved image, attachment url, custom url or none
* Sort images Randomily, Popularity, Date

== Installation ==

= Installation =
1. Upload `instagram-slider-widget` to the `/wp-content/plugins/` directory
2. Activate the plugin through the \'Plugins\' menu in WordPress
3. Go to Appearance > Widgets and drag \'Instagram Slider Widget\' to your sidebar
4. Update the settings in the widget: Instagram Username, Images Layout, Number of Images to show, Check for new images hours 

= Requirements =
* PHP 5.2.0 or later
* Wordpress 3.5 or later

= 1.0 =
* First Realease