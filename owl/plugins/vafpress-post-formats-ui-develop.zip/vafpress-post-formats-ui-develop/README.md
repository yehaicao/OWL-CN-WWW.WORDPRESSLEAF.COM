Vafpress Post Formats UI
========================

Forked version of crowdfavorite's WordPress Post Formats, what's changed?

- Change the default gallery UI, now use post meta to enable more flexibility (images doesn't have to be uploaded to the post and easily sortable)

<p align="left">
  <img src="http://img703.imageshack.us/img703/192/zx6r.png" />
</p>

- Added hooks to enable customizations (e.g. before and after custom UI), example of adding a field:

<p align="left">
  <img src="http://img713.imageshack.us/img713/7927/i1mg.png" />
</p>

Example how to accomplish this: https://gist.github.com/ayublin/8818074